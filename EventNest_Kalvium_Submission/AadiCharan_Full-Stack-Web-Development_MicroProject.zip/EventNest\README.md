# EVENTNEST – College Event Registration Platform
## Kalvium Micro-Project Submission: Full Stack Web Development

> **Student:** Aadi Charan (University Roll No: AU2024BCSE109)  
> **Institution:** Alliance School of Advanced Computing, Alliance University, Bengaluru  
> **Degree Program:** B.Tech Computer Science and Engineering (Kalvium Work-Integrated Learning Program)  
> **Academic Year:** 2026–2027  
> **Course:** Full Stack Web Development  
> **Primary Report File:** [`FullStack_Report.pdf`](./FullStack_Report.pdf) (Also duplicated in `./reports/FullStack_Report.pdf`)  
> **GitHub Repository:** https://github.com/Aadicharan/eventnest  
> **Deployed Application URL:** Localhost Deployment (Demonstrated in local development environment on `http://localhost:5173` and `http://localhost:5000`)

---

## 1. Project Title & Short Description

**EventNest** is an event coordination and registration web application designed to eliminate paper-based signups, chaotic spreadsheet tracking, and double-booking issues across university departments. It features a modern React single-page interface, an Express REST backend with parameterized query handling, and a normalized PostgreSQL relational database that strictly enforces seating limits and registration constraints.

---

## 2. Course-Specific Objectives (Full Stack Web Development)

This package focuses on the end-to-end integration and user interface of EventNest:
- **React 19 Single Page Application:** Modern component hierarchy built with Vite for sub-second development builds.
- **Centralized API Service:** Dedicated client-side HTTP abstraction (`src/services/api.js`) managing network calls and standardizing error handling.
- **Client-Side Routing & State:** React Router DOM for multi-view navigation (Home, Events, Details, Create, Register, Rosters) with reactive state updates.
- **Form Validation & User Feedback:** Immediate user alerts for empty fields, duplicate student entries, and capacity constraints.
- **Full Stack Data Flow:** Seamless flow of data from PostgreSQL tables, through Express REST endpoints, to responsive React components.

---

## 3. Technology Stack

- **Frontend:** React 19, Vite 6, Vanilla CSS design system, React Router DOM, React Hook Form
- **Backend:** Node.js, Express.js 4.x, node-postgres (`pg` Pool), dotenv, cors
- **Database:** PostgreSQL 18.6 Relational Database Engine
- **Tooling & Testing:** Postman Collection v2.1, Node test suite (`test_suite.js`), PowerShell automation

---

## 4. Folder Structure Inside This Submission Package

```
EventNest/
├── README.md                      # Subject-specific documentation and run instructions
├── FullStack_Report.pdf              # Official Alliance University micro-project report (Root)
├── reports/
│   └── FullStack_Report.pdf          # Project report (reports folder copy)
├── database/
│   ├── schema.sql                 # PostgreSQL DDL tables, constraints, foreign keys, indexes
│   └── seed.sql                   # Realistic sample students, events, and registrations
├── backend/                       # Express REST API
│   ├── .env.example               # Safe environment variable configuration template
│   ├── package.json
│   ├── package-lock.json
│   ├── server.js                  # Entry point with pre-flight database connection check
│   ├── app.js                     # Middleware pipeline and route mounting
│   ├── db/index.js                # PostgreSQL connection pool with DATABASE_URL / local support
│   ├── routes/                    # eventsRoutes.js, registrationsRoutes.js
│   ├── controllers/               # eventsController.js, registrationsController.js
│   └── test_api.js                # Quick API smoke test
├── frontend/                      # React 19 SPA (Vite)
│   ├── package.json
│   ├── package-lock.json
│   ├── vite.config.js             # Vite configuration with /api proxy to port 5000
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── index.css
│       ├── components/            # Navbar.jsx, EventCard.jsx, Alert.jsx
│       ├── pages/                 # Home.jsx, Events.jsx, EventDetails.jsx, CreateEvent.jsx, Register.jsx, Registrations.jsx
│       └── services/api.js        # Centralized HTTP service layer
├── docs/
│   ├── er-diagram.png             # Entity Relationship Diagram (Students, Events, Registrations)
│   └── alliance_logo.png          # Official Alliance University crest logo
├── postman/
│   └── EventNest_API.postman_collection.json  # 10 verified Postman API endpoints
├── screenshots/                   # 11 genuine screenshots demonstrating application features
│   ├── output_1_home_dashboard.png
│   ├── output_2_events_catalog.png
│   ├── output_3_event_details.png
│   ├── output_4_create_event_form.png
│   ├── output_5_registration_page.png
│   ├── output_6_registration_validation.png
│   ├── output_7_duplicate_registration_alert.png
│   ├── output_8_full_event_alert.png
│   ├── output_9_successful_registration.png
│   ├── output_10_registrations_table.png
│   └── output_11_api_health_endpoint.png
└── test_suite.js                  # Automated verification test suite (9/9 criteria)
```

---

## 5. Prerequisites

Before running the project locally, ensure the following are installed on your machine:
- **Node.js:** v20.x or v22.x+ LTS (Check with `node -v`)
- **npm:** v10.x+ (Check with `npm -v`)
- **PostgreSQL:** v16+ or v18+ running on port 5432 (Check with `psql --version`)
- **Web Browser:** Google Chrome, Microsoft Edge, or Mozilla Firefox

---

## 6. PostgreSQL Setup Instructions

1. Start your local PostgreSQL server instance.
2. Open your terminal / PowerShell and create the database:
   ```powershell
   psql -U postgres -c "CREATE DATABASE eventnest_db;"
   ```
3. Apply the relational schema (tables, foreign keys, triggers, constraints, indexes):
   ```powershell
   psql -U postgres -d eventnest_db -f "database/schema.sql"
   ```
4. Seed the database with sample students, events, and active registrations:
   ```powershell
   psql -U postgres -d eventnest_db -f "database/seed.sql"
   ```

---

## 7. Environment Variable Configuration

Inside the `backend/` directory, an environment configuration file is required:
- Copy the provided template:
  ```powershell
  cd backend
  cp .env.example .env
  ```
- Edit `backend/.env` to match your local PostgreSQL credentials:
  ```env
  PORT=5000
  PGHOST=localhost
  PGPORT=5432
  PGUSER=postgres
  PGPASSWORD=your_postgres_password
  PGDATABASE=eventnest_db
  ```
*(Note: In cloud environments, the backend also automatically accepts a single `DATABASE_URL` connection string).*

---

## 8. Installation & Run Commands

### Terminal 1: Backend Server (Port 5000)
```powershell
cd backend
npm install
npm start
```
*Expected Output:*
```
Connected to PostgreSQL database at localhost:5432
Database: eventnest_db
EventNest backend server running on http://localhost:5000
```

### Terminal 2: Frontend Client (Port 5173)
```powershell
cd frontend
npm install
npm run dev
```
*Open in browser:* `http://localhost:5173`

---

## 9. API Endpoint Summary

Base URL: `http://localhost:5000/api`

| HTTP Method | Endpoint | Status Codes | Description |
|:---|:---|:---|:---|
| `GET` | `/api` | `200 OK` | API directory and service health check |
| `GET` | `/api/events` | `200 OK` | Returns all events with dynamic seat count calculations |
| `GET` | `/api/events/:id` | `200 OK`, `404 Not Found` | Returns detailed data for a single event |
| `POST` | `/api/events` | `201 Created`, `400 Bad Request` | Publishes a new event with input validation |
| `GET` | `/api/registrations` | `200 OK` | Returns all registrations joined with student and event records |
| `POST` | `/api/registrations` | `201 Created`, `400 Bad Request`, `409 Conflict` | Registers a student; enforces capacity limits & duplicate prevention |

---

## 10. Automated Testing Instructions & Verified Results

Run the built-in automated test suite against the live database:
```powershell
node test_suite.js
```

### Empirical Verification Results:
```
=================================================================
 EVENTNEST: Comprehensive Academic Verification Test Suite
=================================================================
--- Test 1: View Events ---
[PASS] GET /api/events returned HTTP 200 with active events.
--- Test 2: View Event Details ---
[PASS] GET /api/events/1 returned HTTP 200 with complete event details.
--- Test 3: Create Event ---
[PASS] POST /api/events created new event with status 201.
--- Test 4: Empty Form Validation ---
[PASS] Empty input properly rejected with HTTP 400 Bad Request.
--- Test 5: Successful Registration ---
[PASS] POST /api/registrations registered student with status 201.
--- Test 6: Duplicate Registration ---
[PASS] Duplicate registration rejected with HTTP 409 Conflict.
--- Test 7: Full Event Handling ---
[PASS] Full event registration rejected with HTTP 400 Bad Request.
--- Test 8: REST API Response & Status Codes ---
[PASS] Status codes verified: 404 for missing resource, 200 for registrations list.
--- Test 9: Database Relationships & Constraints ---
[PASS] Database relational integrity verified in PostgreSQL catalog (FKs, CASCADE, UNIQUE).
=================================================================
 TEST SUMMARY: 9 / 9 Academic Criteria Passed (100%)
=================================================================
```

---

## 11. Screenshot Index

All screenshots inside the `screenshots/` directory are authentic captures from the running application:
1. `output_1_home_dashboard.png` — Homepage with live counter cards and featured events.
2. `output_2_events_catalog.png` — Event listing showing dynamic "Available" and "Full" badges.
3. `output_3_event_details.png` — Dedicated event breakdown with real-time seat availability.
4. `output_4_create_event_form.png` — Event creation form with client validation rules.
5. `output_5_registration_page.png` — Student registration interface with student identification fields.
6. `output_6_registration_validation.png` — Inline validation error alerts on blank submissions.
7. `output_7_duplicate_registration_alert.png` — HTTP 409 alert preventing repeat student registration.
8. `output_8_full_event_alert.png` — HTTP 400 alert blocking registration when capacity is reached.
9. `output_9_successful_registration.png` — HTTP 201 success confirmation banner.
10. `output_10_registrations_table.png` — Joined 3-table roster displaying registered participants.
11. `output_11_api_health_endpoint.png` — JSON response from root API directory check.

---

## 12. Location of the Subject-Specific Report

- **Report Filename:** `FullStack_Report.pdf`
- **Root Location:** [`./FullStack_Report.pdf`](./FullStack_Report.pdf)
- **Folder Copy:** [`./reports/FullStack_Report.pdf`](./reports/FullStack_Report.pdf)
- **Format:** Official Alliance University Cover Page with authentic crest logo, student details, course title, certificate, declaration, technical analysis, and code evidence.

---

## 13. Mandatory Project Links

- **GitHub Repository URL:** https://github.com/Aadicharan/eventnest  
- **Deployed Application URL:** Localhost Deployment (Demonstrated in local development environment on `http://localhost:5173` and `http://localhost:5000`)  
  *(Note: Free cloud hosting on Render/Vercel requires the student's personal account OAuth credentials. The application includes complete production configuration including `DATABASE_URL` and `VITE_API_URL` support).*

---

## 14. Known Limitations

1. **Authentication:** The current version allows student identification via Student ID and email without password authentication (JWT/OAuth), which is suitable for campus micro-project demonstration.
2. **Email Notifications:** Registrations generate an immediate database record and confirmation screen; integration with an SMTP mailer (e.g., Nodemailer/SendGrid) for email tickets is planned for the next release.
3. **Cancellation Workflow:** Registrations can be viewed across all events; self-service registration cancellation by students will be added in Phase 2.
